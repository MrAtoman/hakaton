from flask import Flask, request, jsonify, send_from_directory
import os
import uuid
import json
import csv
from datetime import datetime
import logging

app = Flask(__name__)
sent_tasks = {}

# Класс-фильтр, который ищет стоп-слово в логах
class NoAgentPollingFilter(logging.Filter):
    def filter(self, record):
        # Если в строке лога есть путь к функции, которую надо скрыть — возвращаем False
        #return "/get_script" not in record.getMessage() and "/" not in record.getMessage() and "/requests" not in record.getMessage() and "/agentslist" not in record.getMessage() and "/logs" not in record.getMessage()
        # Вариант для нескольких исключений
        return all(path not in record.getMessage() for path in ["/get_script", "/requests", "/agentslist", "/logs", "/"])

# Применяем фильтр к логгеру Werkzeug (серверу Flask)
log = logging.getLogger('werkzeug')
log.addFilter(NoAgentPollingFilter())

# Настройки сервера
ADMIN_PASSWORD = "ваш_секретный_пароль"
STORAGE_BASE = 'server_system_data'
AGENT_LOGS_DIR = os.path.join(STORAGE_BASE, 'received_logs')

if not os.path.exists(AGENT_LOGS_DIR):
    os.makedirs(AGENT_LOGS_DIR, exist_ok=True)

# Глобальная переменная для хранения текущей активной задачи
current_active_task = None

@app.route('/')
def index():
    try:
        with open('adminpanel/index.html', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return "Файл index.html не найден", 404
    
@app.route('/requests')
def adminrequests():
    try:
        with open('adminpanel/requests.html', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return "Файл requests.html не найден", 404
    
@app.route('/agentslist')
def agentslist():
    try:
        with open('adminpanel/agentslist.html', 'r', encoding='utf-8') as f:
            return f.read()
    except FileNotFoundError:
        return "Файл agentslist.html не найден", 404

@app.route('/upload', methods=['POST'])
def upload():
    global current_active_task, sent_tasks
    password = request.form.get('admin_password')
    file = request.files.get('script_file')
    
    if password != ADMIN_PASSWORD:
        return "<h1>Ошибка доступа: неверный пароль</h1>", 403
    
    if not file or file.filename == '':
        return "<h1>Ошибка: файл не выбран</h1>", 400

    # Читаем содержимое и формируем задачу
    content = file.read().decode('utf-8')
    commands = [line.strip() for line in content.splitlines() if line.strip()]

    sent_tasks = {}
    
    current_active_task = {
        "id": str(uuid.uuid4()),
        "name": file.filename,
        "commands": commands,
        "created_at": datetime.now().isoformat()
    }
    
    print(f"[*] Скрипт '{file.filename}' готов к раздаче агентам.")
    return f"<h1>Успех!</h1><p>Скрипт {file.filename} поставлен в очередь.</p><a href='/'>Назад</a>"

# --- НОВЫЕ ХРАНИЛИЩА ---
PENDING_AGENTS = "pending_agents.json"   # Кто подал заявку
APPROVED_AGENTS = "approved_agents.json" # Кто принят
AGENT_HEALTH = {} # {agent_id: last_seen_datetime} для статуса Online

def load_json(filename):
    if not os.path.exists(filename): return []
    with open(filename, 'r') as f: return json.load(f)

def save_json(filename, data):
    with open(filename, 'w') as f: json.dump(data, f)

# --- ОБНОВЛЕННЫЕ И НОВЫЕ ЭНДПОИНТЫ ---
BLACKLIST_AGENTS = "blacklist_agents.json"

@app.route('/get_script', methods=['GET'])
def get_script():
    global AGENT_HEALTH
    agent_id = request.args.get('agent_id')
    if not agent_id: return "", 400

    # 1. Проверка на ЧЕРНЫЙ СПИСОК
    blacklist = load_json(BLACKLIST_AGENTS)
    if agent_id in blacklist:
        return jsonify({"error": "rejected"}), 403 # Специальный код для отклоненных

    # 2. Обновляем статус Online (только для тех, кто не в бане)
    AGENT_HEALTH[agent_id] = datetime.now()

    # 3. Проверка на регистрацию
    approved = load_json(APPROVED_AGENTS)
    if agent_id not in approved:
        pending = load_json(PENDING_AGENTS)
        if agent_id not in pending:
            pending.append(agent_id)
            save_json(PENDING_AGENTS, pending)
            print(f"[?] Новый запрос регистрации: {agent_id}")
        return jsonify({"error": "not_registered"}), 401 # Ожидает апрува
    global current_active_task, sent_tasks
    
    if not current_active_task or not agent_id:
        return "", 204

    # КЛЮЧЕВОЕ ИЗМЕНЕНИЕ: Проверка, получал ли этот агент ЭТУ задачу ранее
    if sent_tasks.get(agent_id) == current_active_task['id']:
        return "", 204 # Если ID совпадает, ничего не отправляем

    # Фиксируем отправку
    sent_tasks[agent_id] = current_active_task['id']
    return jsonify(current_active_task)

@app.route('/admin/get_pending')
def get_pending():
    # Возвращаем список UUID из файла ожидающих
    pending = load_json(PENDING_AGENTS)
    return jsonify(pending)

# Эндпоинты для админ-панели (вызываются вашими кнопками Accept/Reject)
@app.route('/admin/approve/<uuid>')
def approve_agent(uuid):
    pending = load_json(PENDING_AGENTS)
    approved = load_json(APPROVED_AGENTS)
    if uuid in pending:
        pending.remove(uuid)
        approved.append(uuid)
        save_json(PENDING_AGENTS, pending)
        save_json(APPROVED_AGENTS, approved)
        print(f"[+] Агент {uuid} успешно зарегистрирован!")
    return "OK"

@app.route('/admin/reject/<uuid>')
def reject_agent(uuid):
    pending = load_json(PENDING_AGENTS)
    if uuid in pending:
        pending.remove(uuid)
        save_json(PENDING_AGENTS, pending)
        print(f"[-] Регистрация агента {uuid} отклонена.")
    return "OK"

@app.route('/admin/get_all_agents')
def get_all_agents():
    approved = load_json(APPROVED_AGENTS)
    results = []
    
    for uid in approved:
        last_seen = AGENT_HEALTH.get(uid)
        # Агент онлайн, если выходил на связь последние 60 секунд
        is_active = False
        if last_seen:
            diff = (datetime.now() - last_seen).total_seconds()
            if diff < 60:
                is_active = True
        
        results.append({
            "uuid": uid,
            "isActive": is_active
        })
    return jsonify(results)

@app.route('/send_results', methods=['POST'])
def receive_results():
    try:
        # Получаем данные
        report_json = json.loads(request.form.get('json_data'))
        log_file = request.files.get('log_file')
        
        agent_id = report_json.get('agent_id')
        agent_ip = report_json.get('ip_address')
        script_name = report_json.get('script_name', 'unknown.py')
        status = report_json.get('status')
        start_time_str = report_json.get('start_server_time')

        # 1. Сохраняем лог файл агента
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        log_filename = f"{agent_id}_{timestamp}.log"
        log_file_path = os.path.join(AGENT_LOGS_DIR, log_filename)
        log_file.save(log_file_path)

        # 2. Вычисляем прошедшее время
        start_dt = datetime.fromisoformat(start_time_str)
        elapsed = datetime.now() - start_dt
        # Форматируем как "Мин:Сек" или "Час:Мин:Сек"
        duration = str(elapsed).split('.')[0] 

        # 3. Запись в CSV (название таблицы = название скрипта)
        csv_filename = f"{script_name}.csv"
        file_exists = os.path.isfile(csv_filename)

        log_url = f"http://{request.host}/download_log/{log_filename}"
        
            # Вместо "http://..." в ячейке будет написано "Скачать лог", но это будет ссылка
        masked_link = f'=ГИПЕРССЫЛКА("{log_url}"; "Скачать лог")'
        
        with open(csv_filename, 'a', newline='', encoding='utf-8-sig') as f:
            writer = csv.writer(f, delimiter=';', quoting=csv.QUOTE_MINIMAL) 
            if not file_exists:
                # Столбцы теперь всегда идут в этом порядке:
                writer.writerow(['name', 'agent uuid', 'agent ip', 'time', 'Status', 'logs'])
            
            writer.writerow([
                script_name,
                agent_id,
                agent_ip,
                duration,
                status,
                masked_link
            ])

        # 4. Вывод в консоль сервера
        log_status = "goal successful complete" if "выполнена задача" in status else "the goal is not completed by error"
        print(f"{agent_id}: {log_status}")

        return jsonify({"status": "received"}), 200
    except Exception as e:
        print(f"Ошибка при обработке отчета: {e}")
        return "Internal Error", 500

@app.route('/download_log/<filename>')
def download_log(filename):
    return send_from_directory(AGENT_LOGS_DIR, filename)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, use_reloader=False)