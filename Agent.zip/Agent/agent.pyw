import requests
import uuid
import json
import platform
import subprocess
import socket
from datetime import datetime
import time
import os
import logging
import sys

# Библиотеки для автозагрузки (нужно: pip install pywin32 winshell)
try:
    import winshell
    from win32com.client import Dispatch
except ImportError:
    pass

# Настройка путей: работаем от расположения скрипта
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
AGENT_DATA_DIR = os.path.join(BASE_DIR, 'agent-system')
LOG_DIR = os.path.join(AGENT_DATA_DIR, 'logs')

if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR, exist_ok=True)

# Индивидуальный лог для этого запуска
CURRENT_LOG_FILE = os.path.join(LOG_DIR, 'agent.log')

logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler(CURRENT_LOG_FILE, encoding='utf-8'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

def add_to_startup():
    """Добавление скрипта в автозагрузку через создание ярлыка"""
    if platform.system() == "Windows":
        try:
            startup_path = winshell.startup()
            shortcut_path = os.path.join(startup_path, "SystemAgentConnector.lnk")
            
            if not os.path.exists(shortcut_path):
                target = sys.executable
                # Если запущен .pyw, аргументом будет сам файл
                script_path = os.path.abspath(__file__)
                
                shell = Dispatch('WScript.Shell')
                shortcut = shell.CreateShortCut(shortcut_path)
                shortcut.Targetpath = target
                shortcut.Arguments = f'"{script_path}"'
                shortcut.WorkingDirectory = BASE_DIR
                shortcut.IconLocation = target
                shortcut.save()
                logger.info("Агент успешно добавлен в автозагрузку Windows")
        except Exception as e:
            logger.error(f"Не удалось добавить в автозагрузку: {e}")

class SimpleAgent:
    def __init__(self, config_file=None):
        if config_file is None:
            config_file = os.path.join(AGENT_DATA_DIR, 'config.json')
            
        self.config_path = config_file
        self.config = self._load_config()
        self.server_url = self.config['server_url']
        self.check_interval = self.config['check_interval']
        self.agent_id = self._load_or_create_id()
        self.system_info = self._collect_basic_info()
        logger.info(f"Агент инициализирован. ID: {self.agent_id}")

    def _load_config(self):
        if not os.path.exists(self.config_path):
            default_config = {
                "server_url": "http://127.0.0.1:5000",
                "check_interval": 30
            }
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(default_config, f, indent=4)
            return default_config
        with open(self.config_path, 'r', encoding='utf-8') as f:
            return json.load(f)

    def _load_or_create_id(self):
        id_file = os.path.join(AGENT_DATA_DIR, 'agent_id.txt')
        if os.path.exists(id_file):
            with open(id_file, 'r', encoding='utf-8') as f:
                return f.read().strip()
        else:
            new_id = str(uuid.uuid4())
            with open(id_file, 'w', encoding='utf-8') as f:
                f.write(new_id)
            return new_id

    def _collect_basic_info(self):
        return {
            'agent_id': self.agent_id,
            'hostname': socket.gethostname(),
            'ip_address': self._get_ip(),
            'platform': platform.system(),
            'timestamp': datetime.now().isoformat()
        }

    def _get_ip(self):
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except Exception:
            return "127.0.0.1"

    def fetch_script(self):
        try:
            # Пытаемся постучаться
            response = requests.get(
                f"{self.server_url}/get_script",
                params={'agent_id': self.agent_id},
                timeout=20
            )
            
            # Логируем успешное соединение (только в системный лог, чтобы не спамить в отчеты)
            logger.info("Соединение с сервером установлено.")

            if response.status_code == 403: # ОТКЛОНЕН (Blacklist)
                data = response.json()
                if data.get('error') == 'rejected':
                    with open(CURRENT_LOG_FILE, 'a', encoding='utf-8') as f:
                        f.write(f"\n[{datetime.now().strftime('%H:%M:%S')}] СТАТУС: Регистрация отклонена администратором. Работа прекращена.\n")
                    return "TERMINATE"

            if response.status_code == 401: # В ОЧЕРЕДИ
                with open(CURRENT_LOG_FILE, 'a', encoding='utf-8') as f:
                    # Проверяем, писали ли мы уже об этом, чтобы не дублировать каждую минуту
                    f.write(f"[{datetime.now().strftime('%H:%M:%S')}] СТАТУС: Отправлена заявка на регистрацию (ожидание одобрения...)\n")
                return "WAITING_APPROVAL"

            if response.status_code == 200:
                return response.json()
            
            return None
        except Exception as e:
            logger.error(f"Ошибка соединения: {e}")
            return None

    def execute_script(self, script_data):
        results = {
            'agent_id': self.agent_id,
            'ip_address': self.system_info['ip_address'],
            'script_id': script_data.get('id'),
            'script_name': script_data.get('name'),
            'start_server_time': script_data.get('created_at'),
            'status': 'выполняется',
            'collected_data': []
        }
        
        commands = script_data.get('commands', [])
        all_success = True

        for cmd in commands:
            try:
                logger.info(f"Запуск команды: {cmd}")
                process = subprocess.run(
                    cmd, 
                    shell=True, 
                    capture_output=True,
                    timeout=120
                )
                
                # Декодирование с приоритетом под RU Windows
                def decode_buf(buf):
                    for enc in ['cp866', 'utf-8', 'cp1251']:
                        try:
                            return buf.decode(enc)
                        except:
                            continue
                    return buf.decode('utf-8', errors='replace')

                stdout = decode_buf(process.stdout)
                stderr = decode_buf(process.stderr)

                if process.returncode != 0:
                    all_success = False

                results['collected_data'].append({
                    'command': cmd,
                    'stdout': stdout,
                    'stderr': stderr,
                    'exit_code': process.returncode
                })
            except Exception as e:
                all_success = False
                results['collected_data'].append({
                    'command': cmd,
                    'error': str(e)
                })
            

        results['status'] = 'выполнена задача' if all_success else 'не выполнена'
        return results

    def send_results(self, results):
        try:
            # Отправляем JSON данные и текущий файл лога
            with open(CURRENT_LOG_FILE, 'rb') as f:
                files = {'log_file': (f'{self.agent_id}.log', f)}
                payload = {'json_data': json.dumps(results)}
                
                response = requests.post(
                    f"{self.server_url}/send_results",
                    data=payload,
                    files=files,
                    timeout=60
                )
                return response.status_code == 200
        except Exception as e:
            logger.error(f"Ошибка отправки отчета: {e}")
            return False

    def run_cycle(self):
        task = self.fetch_script()
        if task:
            logger.info(f"Получена новая задача: {task.get('name')}")
            report = self.execute_script(task)
            if self.send_results(report):
                logger.info(f"Отчет по задаче {task.get('id')} успешно отправлен")
            return True
        return False

    def start(self):
        add_to_startup()
        while True:
            task = self.fetch_script()
            
            if task == "TERMINATE":
                # Пишем в лог и полностью останавливаем бесконечный цикл
                with open(CURRENT_LOG_FILE, 'a', encoding='utf-8') as f:
                    f.write("\n[!] ОШИБКА: Ваша заявка на регистрацию была отклонена сервером.")
                sys.exit() # Завершение работы программы
                
            if task == "WAITING_APPROVAL":
                time.sleep(60) # Увеличиваем ожидание, чтобы не спамить
                continue

            elif isinstance(task, dict):
                # МЕСТО ИЗМЕНЕНИЯ: Если это первая задача после одобрения
                # Можно вывести в консоль: "Агент зарегистрировался успешно (UUID)"
                logger.info("Задача получена. Статус: Регистрация подтверждена.")
                report = self.execute_script(task)
                self.send_results(report)
            
            time.sleep(self.check_interval)

if __name__ == "__main__":
    agent = SimpleAgent()
    agent.start()